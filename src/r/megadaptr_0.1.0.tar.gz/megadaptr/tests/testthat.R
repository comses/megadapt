library(testthat)
library(megadaptr)

test_check("megadaptr")
