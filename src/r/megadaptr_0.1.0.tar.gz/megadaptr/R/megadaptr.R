#' Megadapt spatial microsimulation
#' @import magrittr
#' @exportPattern "*"
"_PACKAGE"
